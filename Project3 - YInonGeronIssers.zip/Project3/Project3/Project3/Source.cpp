#include <stdio.h>
#include <math.h>
#define N 100

int checkExistsBetweenBounds(int A[], int n) {
    return n <= (A[n - 1]) - (A[0]);
}

int findMissingElement(int A[], int n) {
    int low = 0;
    int high = n - 1;
    while (low <= high) {
        int mid = (low + high) / 2;

        if (A[mid] + 1 != A[mid + 1])
        {
            return A[mid] + 1;
        }

        else if (A[high] - A[mid] >= mid)
        {
            low = mid + 1;
        }

        else
        {
            high = mid - 1;
        }

    }

    return -1;
}

int find(int A[], int n) {
    int low = 0;
    int high = n - 1;
    while (low <= high) {
        int mid = low + (high - low) / 2;

        if (A[mid] == mid) {
            return mid;
        }

        else if (A[mid] > mid) {
            high = mid - 1;
        }

        else {
            low = mid + 1;
        }
    }

    return -1;
}

int main() {
    int A[N] = { 0, 1,2, 3, 4, 6, 7, 8};
    int n = 8;

    int exists = checkExistsBetweenBounds(A, n);
    if (exists) {
        printf(" There is an element\n");
    }
    else {
        printf("No such element exists.\n");
    }

    int missingElement = findMissingElement(A,n);
    if (missingElement != -1) {
        printf("The missing element x is: %d\n", missingElement);
    }
    else {
        printf("No missing element found between A[1] and A[n].\n");
    }

    int fixedPoint = find(A,n);
    if (fixedPoint != -1) {
        printf("Fixed point found at index %d where A[%d] = %d\n", fixedPoint, fixedPoint, A[fixedPoint]);
    }
    else {
        printf("No fixed point found where A[i] == i.\n");
    }
}
