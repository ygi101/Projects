interface Fixable {
    void fixed(); // פונקציה שמתקנת את כלי הרכב
}