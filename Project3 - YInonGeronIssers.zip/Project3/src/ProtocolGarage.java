interface ProtocolGarage {
    void fixed(Vehicle vehicle);
}