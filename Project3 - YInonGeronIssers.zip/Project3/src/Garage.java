import java.util.List;

class Garage {
    private Database database;
    private ProtocolGarage protocol;

    public Garage(Database database, ProtocolGarage protocol) {
        this.database = database;
        this.protocol = protocol;
    }

    public void startRepair() {
        List<Vehicle> vehicles = database.getVehicles();

        for (Vehicle vehicle : vehicles) {
            try {
                System.out.println("car care" + vehicle.getName());
                Thread.sleep(1000);
                vehicle.fixed();
                protocol.fixed(vehicle);
            } catch (InterruptedException e) {
                System.out.println("Problem with the fixes");
            }
        }

        System.out.println("All cars fixed");
    }
}