class Car extends Vehicle {
    public Car(String name) {
        super(name);
    }

    @Override
    public void fixed() {
        System.out.println(getName() + "All four wheels fixed");
    }
}
