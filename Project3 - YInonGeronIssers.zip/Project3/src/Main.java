import java.util.Scanner;

public class Main implements ProtocolGarage {
    public static void main(String[] args) {
        Database database = new Database();
        Main main = new Main();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("הזן 1 לאופנוע, 2 למכונית, 3 למשאית או 0 לסיום:");
            int choice = scanner.nextInt();

            if (choice == 0) break;

            System.out.println("הזן את שם הרכב:");
            String name = scanner.next();

            switch (choice) {
                case 1 -> database.addVehicle(new Motorcycle(name));
                case 2 -> database.addVehicle(new Car(name));
                case 3 -> database.addVehicle(new Truck(name));
                default -> System.out.println("בחירה לא חוקית");
            }
        }

        Garage garage = new Garage(database, main);
        garage.startRepair();
    }

    // מימוש של ProtocolGarage
    @Override
    public void fixed(Vehicle vehicle) {
        System.out.println("הרכב " + vehicle.getName() + " סיים את הטיפול.");
    }
}
