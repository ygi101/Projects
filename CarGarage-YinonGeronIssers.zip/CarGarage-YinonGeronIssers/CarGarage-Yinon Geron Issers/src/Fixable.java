public interface Fixable {
    void fixed();
}