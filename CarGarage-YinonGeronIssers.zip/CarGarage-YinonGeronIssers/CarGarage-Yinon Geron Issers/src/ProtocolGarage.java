public interface ProtocolGarage {
    void fixed();
}
